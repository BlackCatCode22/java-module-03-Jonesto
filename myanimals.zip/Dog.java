

public class Dog {

    public static final int MAX_ENERGY = 100;
    private static int dogCount = 0;
    public static int numOfDogs = 0;

    String name;
    int age;
    int energyLevel;

    public void bark() {
        System.out.println("Woof");
    }

    public Dog() {
        dogCount++;
        energyLevel = MAX_ENERGY;
    }

    public static int getDogCount() {
        return dogCount;
    }


}