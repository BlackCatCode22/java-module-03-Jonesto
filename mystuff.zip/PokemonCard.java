public class PokemonCard {
	
	 public static void main(String[] args) {
	        
			Pokemon myCard = new Pokemon();
			myCard.name = "Charizard";
			myCard.attack = "Blast Burn";
			myCard.type = "Fire and Flying";
			myCard.attackPoints = 120;
			
			Pokemon myCard2 = new Pokemon();
			myCard2.name = "Mew";
			myCard2.attack = "Psychic";
			myCard2.type = "Psychic";
			myCard2.attackPoints = 240;			
			
			System.out.println(myCard.attack);
			
			System.out.println(myCard2.attack);
			
	    }

}
   

		
		