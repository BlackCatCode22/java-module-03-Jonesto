
public class Pokemon {
	String attack;
	String name;
    String type;
    int attackPoints;	

}
